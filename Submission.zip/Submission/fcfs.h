/*
 * COP 4600
 * Group 1
 * Johnathan Sattler
 * Michael Slater
 * Christian Theriot
 */

#include <stdio.h>
#include <stdlib.h>
#include "types.h"
#include "queue.h"
#include "helper.h"

void runFcfs(process * head, int runFor, FILE * ofp);