# COP-4600---PA1

Compile: make

Run: ./pa1

Reads processes.in as input. 

Outputs to processes.out.
